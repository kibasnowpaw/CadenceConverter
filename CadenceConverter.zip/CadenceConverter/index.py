import os
import enzyme
import mutagen
from moviepy.editor import *
from tqdm import tqdm

# Directory for finished mp3 files
output_dir = "finished"

# Create the directory if it doesn't exist
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Get list of all .mp4 and .m4b files in the current directory
files = [f for f in os.listdir('.') if os.path.isfile(f) and (f.endswith('.mp4') or f.endswith('.m4b'))]

for i, file in enumerate(tqdm(files, unit="file"), start=1):
    if file.endswith('.mp4'):
        # Convert MP4 to MP3
        video = VideoFileClip(file)
        audio = video.audio
        audio.write_audiofile(os.path.join(output_dir, file.replace('.mp4', '.mp3')))

        # Generate .nfo file for MP4
        with open(file, 'rb') as f:
            mkv = enzyme.MKV(f)
            with open(os.path.join(output_dir, file.replace('.mp4', '.nfo')), 'w') as n:
                n.write(f"Track Number: {i}\n")
                n.write(str(mkv))
    elif file.endswith('.m4b'):
        # Convert M4B to MP3
        audio = AudioFileClip(file)
        audio.write_audiofile(os.path.join(output_dir, file.replace('.m4b', '.mp3')))

        # Generate .nfo file for M4B
        audio = mutagen.File(file, easy=True)
        with open(os.path.join(output_dir, file.replace('.m4b', '.nfo')), 'w') as n:
            n.write(f"Track Number: {i}\n")
            for tag in audio:
                n.write(f"{tag}: {audio[tag]}\n")

print("Conversion and metadata extraction completed.")
